
setwd("C:\\Users\\cduggira\\Desktop\\ds_data_big\\ds_data")
dm<-read.csv("data_train.csv")
dm1<-read.csv("data_test.csv")
summary(dm)


# imputing the missing values with mean & mode
dm$num18[is.na(dm$num18)]<-0.89
dm$num19[is.na(dm$num19)]<-2.346
dm$num20[is.na(dm$num20)]<-0.3799
dm$num22[is.na(dm$num22)]<-0.37
dm$cat1[is.na(dm$cat1)]<-1
dm$cat2[is.na(dm$cat2)]<-0
dm$cat3[is.na(dm$cat3)]<-0
dm$cat4[is.na(dm$cat4)]<-11
dm$cat5[is.na(dm$cat5)]<-1
dm$cat6[is.na(dm$cat6)]<-1
dm$cat8[is.na(dm$cat8)]<-1
dm$cat10[is.na(dm$cat10)]<-1
dm$cat12[is.na(dm$cat12)]<-2

dm1$num18[is.na(dm1$num18)]<-0.89
dm1$num19[is.na(dm1$num19)]<-2.347
dm1$num22[is.na(dm1$num22)]<-0.37
dm1$cat1[is.na(dm1$cat1)]<-1
dm1$cat2[is.na(dm1$cat2)]<-0
dm1$cat3[is.na(dm1$cat3)]<-0
dm1$cat4[is.na(dm1$cat4)]<-11
dm1$cat5[is.na(dm1$cat5)]<-1
dm1$cat6[is.na(dm1$cat6)]<-1
dm1$cat8[is.na(dm1$cat8)]<-1
dm1$cat10[is.na(dm1$cat10)]<-1
dm1$cat12[is.na(dm1$cat12)]<-2  
summary(dm1)  

set.seed(200)

mod<-glm(target~.,data=dm,family="binomial")
summary(mod)

mod1<-glm(formula = target ~ num1+num2+num4+num5+num12+num13+num14+num16+num17+num18+num19+num20+num21+num22+num23+cat1+cat2+cat3+cat4+cat10+cat12, family = "binomial", data = dm)
summary(mod1)

pred<-predict(mod1,type="response",newdata=dm1)

# to find the threshold that decides target value as 0 or 1
table(dm$target)/nrow(dm)

pred1<-ifelse(pred>=0.03643624,1,0)
write.csv(cbind(dm1$id,pred1,pred),file="Output_17-oct.csv")
